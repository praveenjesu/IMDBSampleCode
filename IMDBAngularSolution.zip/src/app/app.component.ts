import { Component, ViewEncapsulation, reserveSlots } from '@angular/core';
import { AppService } from './app.service';

let module;
@Component({
  moduleId: module.id,
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.css'],
  encapsulation: ViewEncapsulation.Emulated
})

export class AppComponent {
  title = 'imdb';
  fileupload: any = [];
  searchText: string = '';
  defaultGuid = '00000000-0000-0000-0000-000000000000';
  movie_id: any = '';
  searchContainer: boolean = false;
  moviedetails: boolean = false;
  movieList: any = null;
  searchResult: boolean = false;
  movieDetails: any = [];
  producerActorDetails: any = '';

  /*Meta Details*/
  options: any = ["Actor", "Producer"];

  /*Variable declaration for add popup*/
  selectedOption: any = '';
  addMovieName: any = '';
  addReleaseDate: any = '';
  addPlot: any = '';
  addPopupName: any = '';
  addPopupDate: any = '';
  addPopupSex: any = '';
  addPopupBio: any = '';
  tempAddActorList: any = '';
  tempAddProducerList: any = '';

  addActorList: any = [];
  addProducerList: any=[];

  /*End of add popup variables*/


  /*Variable for edit popup variables*/


  EditselectedOption: any = '';
  editMovieDetails: any = '';
  tempEditActorList: any = '';
  tempEditProducerList: any = '';

  editActorList: any = '';
  EditActorList: any = '';
  EditProducerList:any=[];

  editPopupName: any = '';
  editPopupDate: any = '';
  editPopupSex: any = '';
  editPopupBio: any = '';

  /*End of Edit popup variables*/

  constructor(private appservice: AppService) {
    this.GetProducerActorList();

  }

  

  addPopupOpen() {
    this.GetProducerActorList();
    this.tempAddActorList = this.producerActorDetails.actorList;
    this.tempAddProducerList = this.producerActorDetails.producerList;
    this.addMovieName = '';
    this.addReleaseDate = '';
    this.addPlot = '';
    this.addPopupName = '';
    this.addReleaseDate = '';
    this.addPopupSex = '';
    this.addPopupBio = '';
    this.addProducerList = '';
    this.addActorList = '';
    this.selectedOption = '';

  }
  pushAddPopup() {
    let tempList: any;
    tempList.Name = this.addPopupName;
    tempList.DOB = this.addPopupDate;
    tempList.Sex = this.addPopupSex;
    tempList.Bio = this.addPopupBio;
    if (this.selectedOption == 'Actor') {
      tempList.actor_id = this.defaultGuid;
      this.tempAddActorList=this.tempAddActorList.concat(tempList);
    }
    else if (this.selectedOption == 'Producer') {
      tempList.producer_id = this.defaultGuid;
      this.tempAddProducerList=this.tempAddProducerList.concat(tempList);
    }
    this.addPopupName = '';
    this.addPopupSex = '';
    this.addReleaseDate = '';
    this.addPopupBio = '';
    
  }
  addActorSelect(index) {
    this.addActorList=this.addActorList.concat(this.tempAddActorList[index]);
  }
  addProducerSelect(index) {
    this.addProducerList = [];
    this.addProducerList = this.tempAddProducerList[index];
  }
  addMovie() {
    let MovieAddDetails: any = '';
    MovieAddDetails.movie_id = null;
    MovieAddDetails.Name = JSON.parse(this.addMovieName);
    MovieAddDetails.Release = JSON.parse(this.addReleaseDate);
    MovieAddDetails.Plot = JSON.parse(this.addPlot);
    MovieAddDetails.actors = JSON.parse(this.addActorList);
    MovieAddDetails.Producer = JSON.parse(this.addProducerList);
    this.appservice.AddMovieList(MovieAddDetails).subscribe(result => {
      let res = result.json();
      if (res == 'Success') {
        this.appservice.GetMovieDetails(MovieAddDetails.movie_id).subscribe(result => {
          this.movieDetails = result.json();
          this.moviedetails = true;
          this.movie_id = this.movieDetails.MovieDetail.movie_id;
          this.searchText = '';
          this.searchContainer = false;
          this.searchResult = false;
        });
      }

    });
  }

  editPopupOpen() {
    this.editActorList = '';
    this.editActorList = this.movieDetails;
    this.tempEditActorList = this.editActorList.actorList;
    this.tempEditProducerList = this.editActorList.producerList;
    this.EditselectedOption = '';
    this.EditActorList = '';
    this.EditProducerList = '';

  }
  pushEditPopup() {
    let tempList: any;
    tempList.Name = this.editPopupName;
    tempList.DOB = this.editPopupDate;
    tempList.Sex = this.editPopupSex;
    tempList.Bio = this.editPopupBio;
    if (this.EditselectedOption == 'Actor') {
      tempList.actor_id = this.defaultGuid;
      this.tempEditActorList.push(tempList);
    }
    else if (this.EditselectedOption == 'Producer') {
      tempList.producer_id = this.defaultGuid;
      this.tempEditProducerList.push(tempList);
    }
    this.editPopupName = '';
    this.editPopupSex = '';
    this.editPopupDate = '';
    this.editPopupBio = '';

  }
 
  editActorSelect(index) {
    this.EditActorList.push(this.tempEditActorList[index]);
  }
  editProducerSelect(index) {
    this.EditProducerList = [];
    this.EditProducerList = this.tempEditProducerList[index];
  }

  pushEditMovie() {
    let MovieAddDetails: MovieAddDetails;
    MovieAddDetails.movie_id = this.movie_id;
    MovieAddDetails.Name = this.editActorList.Name;
    MovieAddDetails.Release = this.editActorList.Release;
    MovieAddDetails.Plot = this.editActorList.Plot;
    MovieAddDetails.actors = this.EditActorList;
    MovieAddDetails.Producer = this.EditProducerList;
    this.appservice.UpdateMovieList(MovieAddDetails).subscribe(result => {
      let res = result.json();
      if (res == 'Success') {
        this.appservice.GetMovieDetails(MovieAddDetails.movie_id).subscribe(result => {
          this.movieDetails = result.json();
          this.moviedetails = true;
          this.movie_id = this.movieDetails.MovieDetail.movie_id;
          this.searchText = '';
          this.searchContainer = false;
          this.searchResult = false;
        });
      }

    });
  }

  /*Guid Generation*/

  GuidGenerate() {
    
    function s4() {
      return Math.floor((1 + Math.random()) * 0x10000)
        .toString(16)
        .substring(1);
    }
    return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
   
  }


  GetProducerActorList() {
    this.appservice.GetActorProducerDetails().subscribe(result => {
      this.producerActorDetails = result.json();
    });
  }

  GetMovieList() {
    if (this.searchText != '') {
      var getList = this.appservice.GetMovieList(this.searchText).subscribe(result => {
        this.searchContainer = true;
        this.movieList = result.json();
      });
    }
    if (this.searchText == '') {
      this.movieList = null;
      this.searchContainer = false;
      this.moviedetails = false;
    }
    if (this.movieList == undefined) {
      this.searchResult = false;
      this.moviedetails = false;
    }
    else {
      this.searchResult = true;
    }
  }

  selectMovieFromList(movie_id) {
    if (this.movie_id != null) {
      var movieDetails = this.appservice.GetMovieDetails(movie_id).subscribe(result => {
        this.movieDetails = result.json();
        this.moviedetails = true;
        this.movie_id = this.movieDetails.MovieDetail.movie_id;
        this.searchText = '';
        this.searchContainer = false;
        this.searchResult = false;
        
      });
    }
  }

  deleteMovie() {
    if (this.movie_id != null && this.movie_id != '') {
      this.appservice.DeleteMovieList(this.movie_id).subscribe(result => {
        this.searchText = '';
        this.searchContainer = false;
        this.searchResult = false;
        this.movie_id = '';
        this.movieDetails = null;
        this.moviedetails = false;

      });
    }
  }


  uploadfile(event) {
    this.fileupload = event.target.files[0];
    var formdata: FormData = new FormData();
    formdata.append('fileupload',this.fileupload);
    this.appservice.saveMovieDetails(formdata, this.movie_id).subscribe(result => {
      this.moviedetails = false;
      if (result.json()=="Success")
      this.selectMovieFromList(this.movie_id);
    });
  }
}
export class MovieAddDetails {
  movie_id: string = '';
  Name: string = '';
  Release: Number = 0;
  Plot: string = '';
  actors: ActorList[] = [];
  Producer: producer[] = [];

}
export class ActorList {
  Name: string = '';
  DOB: any = '';
  Sex: string = '';
  Bio: string = '';

}
export class producer {
  Name: string = '';
  DOB: any = '';
  Sex: string = '';
  Bio: string = '';

}


