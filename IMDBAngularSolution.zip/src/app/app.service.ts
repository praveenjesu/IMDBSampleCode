import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';


@Injectable()
export class AppService {

  host: string = 'http://localhost:54019/';
  options: RequestOptions;
  headers: Headers;

  constructor(private http: Http) {
    this.options = new RequestOptions({ headers: this.headers });
  }
  /*Filtering the movie list based on user search*/
  GetMovieList(searchText: any): Observable<any> {
    if (searchText == undefined)
      searchText = '';
    if (searchText != '') {
      let url = this.host + 'api/movieList' + '?searchText=' + searchText;
      return this.http.get(url);
    }
  }

  /*Priting the details of the selected movie*/
   GetMovieDetails(movie_id: any): Observable<any> {
    let url = this.host + 'api/moviedetails' + '?movie_id=' + movie_id;
    return this.http.get(url);
  }
  /*Listing all the actors and producers available in the database*/
  GetActorProducerDetails(): Observable<any> {
    let url = this.host + 'api/actorproducerdetails';
    return this.http.get(url);
  }

  /*Add new movie*/
  AddMovieList(movieDetails: any): Observable<any> {
    let url = this.host + 'api/addnewmovieDetails';
    return this.http.post(url, movieDetails);

  }
  /*Update Image poster for the movie*/
  saveMovieDetails(formData: any, movie_id: any): Observable<any> {
   
    let url = this.host + 'api/postImagePoster' + '?movie_id=' + movie_id;
    return this.http.post(url, formData);
  }


  /*Editing the selected movie details*/
  UpdateMovieList(movieDetails: any): Observable<any> {
    let url = this.host + 'api/updatemovieDetails';
    return this.http.put(url, movieDetails);
  }

  /*Removing the selected movie*/
  DeleteMovieList(movie_id: any): Observable<any> {

    return this.http.get(this.host + 'api/deletemoviedetails' + '?movie_id=' + movie_id);
  }
}
