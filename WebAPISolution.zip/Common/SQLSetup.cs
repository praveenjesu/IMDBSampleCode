﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Configuration;
namespace WebApplication1.Common
{
    public class SQLSetup
    {
        public SqlConnection SqlConnectionSetup()
        {
            SqlConnection sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());

            return sqlConnection;
        }
    }
}